# The Vidyakunj School Navsari — Codemagic Build Package

This package is ready to upload to **Codemagic** for a one-click Android APK build.


## What is included
- `flutter_app/` : Flutter app key files (lib/, pubspec.yaml). Use `flutter create` to complete scaffolding or Codemagic will run `flutter pub get`.
- `node_server/` : Node.js server to securely forward attendance to Gupshup.
- `students_template.csv` : CSV template for roster import.
- `codemagic.yaml` : Codemagic workflow to build Android release APK.

## Important environment variables to set in Codemagic (do NOT commit these to git)
- `MASTER_API_KEY` : secret used by the app to call your Node server (set to a strong random string)
- `GUPSHUP_USERID` : your Gupshup userid (e.g., 2000176036)
- `GUPSHUP_PASSWORD` : your Gupshup password
- `SERVER_URL` : public HTTPS URL where the Node server will be hosted (e.g., https://your-vps.example.com)

## Steps to build on Codemagic
1. Create a GitHub repo and push contents of `flutter_app/` (lib/, pubspec.yaml, android/ created by `flutter create` if desired) and `codemagic.yaml`.
2. Create a Codemagic account and connect your GitHub repo.
3. In Codemagic project settings -> Environment variables, add the variables above as *secure* variables.
4. Start the build (Codemagic will run `flutter build apk --release` and produce the release APK).

## Node server
- Deploy `node_server/server.js` on a small VPS (DigitalOcean/Render/Heroku). Set environment variables `MASTER_API_KEY`, `GUPSHUP_USERID`, `GUPSHUP_PASSWORD` there.
- The Flutter app will call `${SERVER_URL}/send_attendance` with header `x-api-key: MASTER_API_KEY`.

## Support
I can guide your technician while they upload the repo to Codemagic and set env vars. Reply when you're ready and I'll walk you through each click.
