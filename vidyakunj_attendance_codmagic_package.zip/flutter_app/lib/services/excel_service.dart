import 'dart:io';
import 'package:file_picker/file_picker.dart';
import '../services/db_service.dart';
import 'package:excel/excel.dart';
import '../services/auth_service.dart';

class ExcelService {
  static Future importStudents() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['csv','xlsx']);
    if(res == null) return;
    final bytes = res.files.first.bytes ?? File(res.files.first.path!).readAsBytesSync();
    if(res.files.first.extension == 'csv') {
      final content = String.fromCharCodes(bytes);
      final lines = content.split('\n');
      final headers = lines.first.split(',');
      for(final line in lines.skip(1)) {
        if(line.trim().isEmpty) continue;
        final cols = line.split(',');
        final s = {
          'roll': cols[0].trim(),
          'name': cols[1].trim(),
          'division': cols[2].trim(),
          'grade': cols[3].trim(),
          'parent_name': cols[4].trim(),
          'parent_phone': cols[5].trim()
        };
        await DBService.insertStudent(s);
      }
    } else {
      final excel = Excel.decodeBytes(bytes);
      final sheet = excel.tables[excel.tables.keys.first];
      for(final row in sheet!.rows.skip(1)) {
        final first = row[0]?.value?.toString() ?? '';
        if(first.toLowerCase()=='admin_user') {
          // special row format: admin_user,username,password
          final username = row[1]?.value?.toString() ?? '';
          final password = row[2]?.value?.toString() ?? '';
          if(username.isNotEmpty) await AuthService.createUser(username, password);
          continue;
        }
        final s = {
          'roll': row[0]?.value?.toString() ?? '',
          'name': row[1]?.value?.toString() ?? '',
          'division': row[2]?.value?.toString() ?? '',
          'grade': row[3]?.value?.toString() ?? '',
          'parent_name': row[4]?.value?.toString() ?? '',
          'parent_phone': row[5]?.value?.toString() ?? ''
        };
        await DBService.insertStudent(s);
      }
    }
  }
}
