import 'dart:convert';
import 'package:http/http.dart' as http;

class SmsService {
  static Future<bool> submitAttendanceToServer(List attendance, String grade, String division, String date) async {
    final serverUrl = const String.fromEnvironment('SERVER_URL', defaultValue: 'https://your-server.example.com');
    final apiKey = const String.fromEnvironment('MASTER_API_KEY', defaultValue: 'CHANGE_ME');
    final uri = Uri.parse('$serverUrl/send_attendance');
    final res = await http.post(uri,
      headers: {'Content-Type':'application/json', 'x-api-key': apiKey},
      body: jsonEncode({'grade':grade,'division':division,'date':date,'attendance':attendance})
    );
    return res.statusCode == 200;
  }
}
