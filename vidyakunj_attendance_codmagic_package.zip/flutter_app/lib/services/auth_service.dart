import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'db_service.dart';

class AuthService {
  static final _storage = FlutterSecureStorage();

  // Simple credential store in secure storage; admin can add users via CSV import (special header)
  static Future<bool> login(String username, String password) async {
    final val = await _storage.read(key: 'user_$username');
    if(val == null) return false;
    return val == password;
  }

  static Future<void> createUser(String username, String password) async {
    await _storage.write(key: 'user_$username', value: password);
  }

  static Future<void> logout() async { /* no-op */ }
}
