import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DBService {
  static Database? _db;
  static Future init() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'attendance.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, v) async {
      await db.execute('''CREATE TABLE students (id INTEGER PRIMARY KEY AUTOINCREMENT, roll TEXT, name TEXT, division TEXT, grade TEXT, parent_name TEXT, parent_phone TEXT)''');
      await db.execute('''CREATE TABLE attendance (id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER, date TEXT, status TEXT)''');
    });
  }

  static Future<List<Map<String,dynamic>>> getStudents({String? grade, String? division}) async {
    final db = _db!;
    final res = await db.query('students', where: 'grade=? AND division=?', whereArgs: [grade, division], orderBy: 'roll');
    return res;
  }

  static Future insertStudent(Map<String,dynamic> s) async {
    final db = _db!;
    await db.insert('students', s, conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
