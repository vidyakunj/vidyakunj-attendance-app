import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/db_service.dart';
import '../services/excel_service.dart';
import '../services/sms_service.dart';
import '../services/auth_service.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedGrade = '8';
  String selectedDivision = 'A';
  DateTime selectedDate = DateTime.now();
  List students = [];

  @override
  void initState() {
    super.initState();
    loadStudents();
  }

  Future loadStudents() async {
    final s = await DBService.getStudents(grade: selectedGrade, division: selectedDivision);
    setState(() { students = s; });
  }

  void togglePresent(int index) {
    setState(() {
      students[index]['isPresent'] = !(students[index]['isPresent'] ?? true);
    });
  }

  Future submitAttendance() async {
    final att = students.map((s) => {
      'student_id': s['id'],
      'roll': s['roll'],
      'name': s['name'],
      'parent_name': s['parent_name'],
      'parent_phone': s['parent_phone'],
      'status': (s['isPresent'] ?? true) ? 'present' : 'absent',
    }).toList();

    final ok = await SmsService.submitAttendanceToServer(att, selectedGrade, selectedDivision, DateFormat('yyyy-MM-dd').format(selectedDate));
    final snack = ok ? 'Attendance submitted' : 'Failed to submit (will queue)';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(snack)));
  }

  void logout() async {
    await AuthService.logout();
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Attendance — Grade $selectedGrade $selectedDivision'), actions: [
        IconButton(icon: Icon(Icons.logout), onPressed: logout)
      ]),
      body: Column(
        children: [
          Row(children: [
            DropdownButton<String>(value: selectedGrade, items: ['6','7','8','9','10'].map((g)=>DropdownMenuItem(child:Text(g), value:g)).toList(), onChanged: (v){selectedGrade=v!;loadStudents();}),
            SizedBox(width:10),
            DropdownButton<String>(value: selectedDivision, items: ['A','B','C','D'].map((d)=>DropdownMenuItem(child:Text(d), value:d)).toList(), onChanged: (v){selectedDivision=v!;loadStudents();}),
            SizedBox(width:10),
            ElevatedButton(onPressed: () async { await ExcelService.importStudents(); loadStudents(); }, child: Text('Upload CSV/XLSX')),
          ]),
          Expanded(child: ListView.builder(itemCount: students.length, itemBuilder: (ctx,i){
            final s = students[i];
            return ListTile(
              title: Text('${s['roll']}. ${s['name']}'),
              subtitle: Text(s['parent_phone'] ?? ''),
              trailing: Switch(value: s['isPresent'] ?? true, onChanged: (_){ togglePresent(i); }),
            );
          })),
          ElevatedButton(onPressed: submitAttendance, child: Text('Submit Attendance')),
          SizedBox(height:12)
        ],
      ),
    );
  }
}
