import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  String _err = '';

  void _login() async {
    final ok = await AuthService.login(_userCtrl.text.trim(), _passCtrl.text.trim());
    if(ok) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomeScreen()));
    } else {
      setState(() { _err = 'Invalid credentials'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Vidyakunj Login')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          TextField(controller: _userCtrl, decoration: InputDecoration(labelText: 'Username')),
          TextField(controller: _passCtrl, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
          SizedBox(height:12),
          ElevatedButton(onPressed: _login, child: Text('Login')),
          if(_err.isNotEmpty) Text(_err, style: TextStyle(color: Colors.red)),
        ]),
      ),
    );
  }
}
