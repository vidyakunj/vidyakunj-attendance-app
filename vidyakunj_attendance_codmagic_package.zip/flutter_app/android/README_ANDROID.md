When building on Codemagic, set these ENV vars in the UI as Secure variables:

MASTER_API_KEY = <strong random string>
GUPSHUP_USERID = 2000176036 (example)
GUPSHUP_PASSWORD = <your gupshup password>
SERVER_URL = https://your-server.example.com
