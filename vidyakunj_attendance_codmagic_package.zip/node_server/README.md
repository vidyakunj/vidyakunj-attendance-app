# Node Server (Gupshup Integration)


1. Set environment variables: MASTER_API_KEY, GUPSHUP_USERID, GUPSHUP_PASSWORD
2. Install dependencies: `npm install axios qs express body-parser`
3. Run: `node server.js` (use pm2 or systemd for production)
4. Secure with HTTPS and restrict access via firewall or API key.
