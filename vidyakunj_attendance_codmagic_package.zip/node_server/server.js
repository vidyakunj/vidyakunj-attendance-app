const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const qs = require('qs');

const app = express();
app.use(bodyParser.json());

const API_KEY = process.env.MASTER_API_KEY || 'CHANGE_ME';
const GUP_USER = process.env.GUPSHUP_USERID || 'YOUR_GUPSHUP_USERID';
const GUP_PASS = process.env.GUPSHUP_PASSWORD || 'YOUR_GUPSHUP_PASSWORD';

app.post('/send_attendance', async (req, res) => {
  if(req.headers['x-api-key'] !== API_KEY) return res.status(401).send('Unauthorized');
  const { grade, division, date, attendance } = req.body;
  const results = [];
  for(const s of attendance) {
    if(s.status === 'absent') {
      const message = `Dear Parents,Your child, ${s.name} remained absent in school today.,Vidyakunj School`;
      try {
        const payload = qs.stringify({
          method: 'SendMessage',
          send_to: s.parent_phone.replace('+',''),
          msg: message,
          msg_type: 'TEXT',
          userid: GUP_USER,
          auth_scheme: 'PLAIN',
          password: GUP_PASS,
          v: '1.1',
          format: 'JSON'
        });
        const r = await axios.post('https://enterprise.smsgupshup.com/GatewayAPI/rest', payload, {
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });
        results.push({student_id: s.student_id, ok: true, providerResp: r.data});
      } catch(e) {
        results.push({student_id: s.student_id, ok: false, error: e.toString()});
      }
    }
  }
  res.json({ok:true, results});
});

const port = process.env.PORT || 3000;
app.listen(port, ()=>console.log('SMS server running on port', port));
